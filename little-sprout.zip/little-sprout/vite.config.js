import { defineConfig } from 'vite';

export default defineConfig({
  // Relative paths so the built game in dist/ works from any folder.
  base: './',
  server: { open: true },
});
