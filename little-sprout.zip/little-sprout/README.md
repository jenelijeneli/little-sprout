# Little Sprout 🌱

A cozy, hand-drawn fantasy farming game that runs in your web browser.
Plant seeds in a cottage garden below the mountains, water them, harvest,
sell your crops, make friends with garden creatures, finish quests, and
decorate the inside of your thatched cottage with furniture you buy.

![A lived-in Little Sprout garden](docs/screenshot.png)

![Inside the cottage](docs/house.png)

All the artwork is original SVG drawn for this game, and everything runs
on your own computer. No accounts, servers or internet connection needed
once it is installed.

---

## 1. Install (one time only)

You need **Node.js** (version 18 or newer). Download the "LTS" version from
<https://nodejs.org> and install it like any other program.

Then open a terminal **in this folder** (the one with `package.json`):

- **Windows:** open the folder in File Explorer, click the address bar, type `cmd`, press Enter.
- **Mac:** right-click the folder in Finder → *New Terminal at Folder*.

Run:

```bash
npm install
```

This downloads Vite (the small tool that runs the game) and two font
packages into a `node_modules` folder. You only need to do it once.

## 2. Play

```bash
npm run dev
```

Your browser opens the game automatically. If it doesn't, open the address
the terminal prints, usually <http://localhost:5173>.
To stop the game, click the terminal and press **Ctrl + C**.

### Other commands

| Command | What it does |
| --- | --- |
| `npm run dev` | Start the game for playing and editing. Changes you save show up instantly. |
| `npm test` | Run the automated checks for the game rules (27 tests). |
| `npm run build` | Make a finished copy of the game in the `dist/` folder. |
| `npm run preview` | Play that finished copy from `dist/`. |

---

## 3. How to play

| Action | How |
| --- | --- |
| **Plant** | Click an empty patch of soil and choose a seed (tabs sort them into Vegetables, Fruits and Flowers). After that, every empty patch you click gets the same seed until you press **×** on the green "Planting…" tag. |
| **Check on a plant** | Click it to see its stage, a progress bar and the time left. |
| **Water** | A 💧 bubble means the plant is thirsty. Click the plant and press **Water**, or pick up the **Water** can from the toolbar and click thirsty plants. Wet soil makes plants grow **1.5× faster** for a while. |
| **Harvest** | A basket bubble and a golden ring mean it's ripe. Just click it. |
| **Crop signs** | Every bed has a little wooden sign showing what grows there. Click it to plant, water or harvest the whole bed at once. |
| **Scarecrow** | Click him for a quick report: how many plants are ripe, thirsty or empty. |
| **Garden gate** | The gate at the front opens the seed shop. |
| **Go inside** | Click the cottage door (or **Home** in the toolbar). The screen fades and you're inside. **Go outside** (the door on the right, or the toolbar button) takes you back. Your crops keep growing while you're indoors. |
| **Furnish the cottage** | Inside, open **Furnish** (or **Shop → Furniture** from the garden). Pick a category, press **Buy** and a see-through copy follows your mouse: green means it fits, red means it doesn't (the note says why). Click to put it down, press **F** or **Flip** to turn it around, and **Esc** or **Cancel** to keep it in storage. |
| **Move, flip or store furniture** | Click any furniture in the room. **Store** puts it back in **Furnish → Stored**, ready to place again. Lamps and vases on a table travel with the table. |
| **Sell** | **Shop → Sell**, or from your **Basket**. |
| **Orders** | **Shop → Orders**: neighbours pay extra for specific produce. |
| **Buy seeds, decorations and furniture** | **Shop → Seeds / Decor / Furniture**. |
| **Decorate** | Open **Decorate**, pick an item from your shed, click a glowing circle in the garden. Click a placed item to put it back. |
| **Friends** | Click a creature in the garden (or open **Friends**) to pet or feed it. Happy friends give bigger bonuses. |
| **Quests** | Open **Quests** and press **Claim!** when one is finished. |
| **Expand** | The garden has 12 beds (24 plots); you start with 6. Reach the required level, then **Expand** clears two overgrown beds for 4 more plots (levels 3, 5 and 7). |
| **Settings** | The gear (top right): save now, reduce motion, reset the farm. |
| **Close things** | **Esc** closes pop-ups and panels, puts tools away and cancels furniture placing. |

Plants keep growing while the game is closed: they catch up as soon as you come back.

### The crops

| Level | Vegetables | Fruits | Flowers |
| --- | --- | --- | --- |
| 1 | carrot, radish, lettuce | | |
| 2 | turnip, onion | strawberry | |
| 3 | cabbage, potato, garlic, tomato | | |
| 4 | eggplant, cucumber | blueberry | sunflower |
| 5 | bell pepper, pumpkin | raspberry, watermelon | |
| 6 | corn, chili | | moonbloom |
| 7 | broccoli | grapes | |
| 8 | | apple, pear | |
| 9 | | peach | |

Every crop has its own seed price, growing time, harvest size, sell price and
experience. Cheap starters (carrot, radish, lettuce) grow in under a minute;
bigger crops take longer but are worth more. Root crops (carrot, turnip,
radish, potato, onion, garlic) show their tops above the soil; watermelons,
pumpkins and cucumbers sprawl on vines; apples, pears and peaches grow on
little trees. Cucumbers, garlic and watermelons are thirsty and get an extra
boost from water.

### The cottage furniture

24 items in four groups, each with its own price and unlock level:

- **Furniture:** wooden bed, dining table, chair, bedside table, bookshelf, sofa, wardrobe
- **Lighting:** wall lantern, table lamp, hanging light
- **Decorations:** potted flowers, flower vase, framed painting, round rug, striped runner, wall clock, cushions, wall shelf, indoor plant
- **Special:** cast-iron stove, copper pot rack, harvest wreath, pumpkin trio, fairy lights

Each item knows where it can go: on the floor, flat on the floor (rugs), on
the wall, from the ceiling beam, or on top of a table, bedside table, bed,
sofa or stove. Things can't overlap, cover the fireplace, window or door, or
leave the room. The cottage starts with a bed, a table, a chair and a rug.

### The garden friends

| Friend | Arrives | Loves | Bonus (at 100% happiness) |
| --- | --- | --- | --- |
| **Button**, Puffcap Mushroom | at the start | carrots | 30% chance of an extra item per harvest |
| **Posy**, Flower Sprite | level 3, 120 coins | strawberries | +25% experience from harvests |
| **Sprig**, Leaf Dragon | level 5, 300 coins | sunflowers | every crop grows 20% faster |

Bonuses shrink as happiness drops, and happiness drifts down slowly over time,
so check in on your friends. Petting gives +8 (once every 15 seconds), a favourite
snack gives +25 and any other produce +12.

---

## 4. Changing the game (customisation)

Everything you're likely to want to tweak lives in `src/data/`. Save a
file while `npm run dev` is running and the browser updates by itself.

| I want to… | Edit |
| --- | --- |
| Make crops grow slower (real-time farming) | `src/data/config.js` → `GROWTH_TIME_SCALE`. `1` = quick testing times (carrots take 30 s). `60` turns every second into a minute. |
| Change starting coins or seeds | `src/data/config.js` → `STARTING_COINS`, `STARTING_SEEDS` |
| Change how strong watering is | `src/data/config.js` → `WATER_SPEED`, `WATER_DURATION_SHARE` |
| Change prices, sell values, XP or unlock levels | `src/data/cropsData.js` |
| Change creature bonuses, prices or favourite foods | `src/data/creaturesData.js` |
| Add or edit quests | `src/data/questsData.js` (the comment at the top lists quest types) |
| Change decorations | `src/data/decorData.js` |
| Change furniture (prices, sizes, where it may go) | `src/data/furnitureData.js` (the comment at the top explains each field) |
| Change the room's walls, floor and blocked areas | `src/data/houseLayout.js` |
| Move beds, the cottage, scarecrow, gate, decoration spots or creature walking spots | `src/data/gardenLayout.js` |
| Change expansion costs | `src/data/config.js` → `EXPANSIONS` |
| Change colours and fonts | top of `src/styles/main.css` |

### Adding a new crop

1. Add an entry to `src/data/cropsData.js` with a new `id`, for example `kale`, and a `category`
   (`vegetable`, `fruit` or `flower`). You can also give it its own `waterSpeed`.
2. Add pictures with matching names:
   - `src/assets/crops/kale-0.svg` to `kale-3.svg` (seed, sprout, growing, ready)
   - `src/assets/produce/kale.svg` (the harvested item)
   - `src/assets/seeds/kale.svg` (the seed packet)

   The easiest start is to copy the carrot files and edit the colours.

### Editing the artwork

Every picture is a plain `.svg` file in `src/assets/`. You can open them in
a free editor such as [Inkscape](https://inkscape.org), or in a text editor
to change colours (look for `fill="#ec8a3a"` and similar). Keep the same
file names and the game picks up your changes.

Art conventions, so new drawings match:

- Outline colour `#4a3428` (warm dark brown), round line joins.
- Line width about 2.8 in the 100-wide crop pictures, 3 in the 64-wide icons.
- Cel shading: each shape has a flat base colour, one darker crescent on its
  lower-right side and a small cream highlight on the upper-left. Leaves are
  split down the middle, with one half a shade darker.
- The shading uses SVG `<clipPath>`s. Each file gives its clip ids a unique
  prefix (for example `carrot3-1`), so if you copy a file, rename the ids too.
- Crops are drawn in a 100 × 120 box with the base of the plant at about y = 106.
- Soil plots come in three shapes (`garden/plot-0.svg` to `plot-2.svg`, each
  with a `-wet` version). The game picks one per plot so beds don't look stamped.
- The garden is built from separate layers, not one flat picture: the valley
  background (`garden/background.svg`: sky, mountains, lake, village, hills,
  fences and soil beds), the cottage (`garden/cottage.svg`, its door and water
  wheel animate), the scarecrow, the gate, the crop signs, the soil plots and
  the crops, each positioned by the game.
- The cottage inside is `house/interior.svg` (1200 × 800). Furniture lives in
  `src/assets/furniture/`, one file per item, drawn to fill its size.
- Panels, buttons and the toolbar get their paper and wood textures from
  `src/assets/ui/` and `src/styles/art.css`.

### Adding new furniture

1. Add an entry to `src/data/furnitureData.js` (id, name, category, cost, unlock level, where it can go, size).
2. Draw `src/assets/furniture/<id>.svg` with a `viewBox` of `0 0 w h` matching its size, standing on the bottom edge.

### Developer shortcuts

While `npm run dev` is running, open the browser's developer console
(F12 → Console) and type:

- `sprout.warp(60)` skips 60 seconds ahead, so plants grow instantly.
- `sprout.coins(500)` adds 500 coins.

These only exist in development mode, not in the built game.

---

## 5. Saving

- The game saves to your browser's local storage after every action, every 10 seconds, and when you close the tab. The "Saved" note at the top flashes when it does.
- Saves belong to **this browser on this computer**. A different browser starts a new garden.
- Saves made before the cottage update are upgraded automatically: crops, coins, quests, friends and decorations all stay, and the cottage gets its starter furniture. Before upgrading, the old save is copied to `little-sprout-save-backup-v1` in the browser's storage, once, and never overwritten.
- Furniture you own is never thrown away: if a saved item no longer fits where it was, it goes back to storage.
- If a save is damaged or from an older version, the game keeps everything it can understand and fills in the rest, so changing the game's code won't wipe your progress. A completely unreadable save is set aside (as `little-sprout-save-broken`) and a new garden begins.
- **Settings → Reset farm** starts over, after asking you to confirm.

---

## 6. Project layout

```
index.html              the page
src/main.js             starts the game
src/data/               numbers and lists you can edit (crops, quests, layout…)
src/systems/            game rules, no drawing code (easy to test)
  game.js               runs actions, counts quests, saves
  crops.js              planting, growth over time, watering, harvesting
  economy.js            coins, levels, selling, market orders
  creatures.js          happiness, petting, feeding, bonuses
  quests.js             quest progress and rewards
  decorations.js        buying and placing decorations
  home.js               the cottage: buying, placing, moving, storing furniture
  expansion.js          unlocking more garden beds
  saveManager.js        loading, checking and saving the game
src/components/         everything on screen
  app.js                connects the screen to the game rules
  garden.js             the garden scene: beds, cottage, scarecrow, gate, crop signs
  house.js              the cottage interior and furniture placement
  hud.js, dock.js       top bar and bottom toolbar
  shop.js, inventoryPanel.js, questPanel.js, creaturePanel.js,
  decoratePanel.js, expandPanel.js, settingsPanel.js,
  furnishPanel.js       the side panels
  effects.js            floating rewards, toasts, confetti
src/styles/             main.css (colours, buttons), garden.css, ui.css,
                        art.css (paper, wood and shading for the interface),
                        house.css (cottage, scarecrow, gate, interior, furniture)
src/assets/             all the SVG artwork
tests/game.test.js      automated tests for the rules
tests/home.test.js      tests for the new crops, furniture and save upgrade
```

## 7. Known limitations

- Single player, one garden per browser. There's no cloud save or export yet.
- Garden decorations go on 8 fixed spots rather than anywhere you like (cottage furniture can go anywhere it fits).
- The room is seen from the front, so furniture can be flipped left and right but not rotated to face other directions.
- On a phone the garden and cottage are small and placing furniture with a finger is fiddly; a computer or tablet works best.
- Which scene you're in (garden or cottage) isn't saved, so the game always opens in the garden.
- No sound or music yet.
- Creature happiness and growth bonuses use the bonus as it is *now* when catching up on time spent away, so they're a close estimate rather than an exact one.
